/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfilo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/16 08:45:01 by mfilo             #+#    #+#             */
/*   Updated: 2024/06/16 08:57:10 by mfilo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;
	int	elemento;

	i = 0;
	while (i < size / 2)
	{
		elemento = tab[i];
		tab[i] = tab[size - i - 1];
		tab[size - i - 1] = elemento;
		i++;
	}
}
