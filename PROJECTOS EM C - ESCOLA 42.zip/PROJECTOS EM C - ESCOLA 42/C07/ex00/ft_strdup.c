/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfilo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/01 12:09:00 by mfilo             #+#    #+#             */
/*   Updated: 2024/07/01 12:09:16 by mfilo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		++i;
	return (i + 1);
}

char	*ft_strdup(char *src)
{
	char	*strcpy;
	int		len;
	int		i;

	len = ft_strlen(src);
	strcpy = malloc (sizeof(strcpy) * len);
	if (!strcpy)
		return (NULL);
	i = 0;
	while (i < len)
	{
		strcpy[i] = src[i];
		++i;
	}
	return (strcpy);
}
