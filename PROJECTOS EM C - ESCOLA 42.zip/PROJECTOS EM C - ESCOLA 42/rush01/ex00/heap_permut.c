/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heap_permut.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efinda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/10 04:05:06 by efinda            #+#    #+#             */
/*   Updated: 2024/03/10 04:05:10 by efinda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	add_permut(const int *v, int permut[24][4], int *cur);

void	swap(int *x, int *y);

void	heappermute(int c[], int n, int permut[24][4], int *cur)
{
	int	i;

	if (n == 1)
	{
		add_permut(c, permut, cur);
	}
	else
	{
		i = 0;
		while (i < n)
		{
			heappermute(c, n - 1, permut, cur);
			if (n % 2 == 1)
				swap(&c[0], &c[n - 1]);
			else
				swap(&c[i], &c[n - 1]);
			i++;
		}
	}
}

void	get_permut(int permut[24][4])
{
	int	el[4];
	int	cur;

	cur = 0;
	el[0] = 1;
	el[1] = 2;
	el[2] = 3;
	el[3] = 4;
	heappermute(el, 4, permut, &cur);
}

void	add_permut(const int *v, int permut[24][4], int *cur)
{
	permut[*cur][0] = v[0];
	permut[*cur][1] = v[1];
	permut[*cur][2] = v[2];
	permut[*cur][3] = v[3];
	(*cur)++;
}
